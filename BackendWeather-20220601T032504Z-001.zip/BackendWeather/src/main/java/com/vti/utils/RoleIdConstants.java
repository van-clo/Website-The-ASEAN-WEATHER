package com.vti.utils;

public class RoleIdConstants {
    public static final int ROLE_USER = 1;
    public static final int ROLE_ADMIN = 2;
}
