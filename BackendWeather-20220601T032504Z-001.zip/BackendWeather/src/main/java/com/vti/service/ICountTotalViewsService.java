package com.vti.service;

public interface ICountTotalViewsService {
	
	public void updateCountTotalViews(int count);
	
	public int getCount();
}
