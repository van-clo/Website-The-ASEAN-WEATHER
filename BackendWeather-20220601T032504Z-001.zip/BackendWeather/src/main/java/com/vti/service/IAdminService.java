package com.vti.service;

public interface IAdminService {
	
	public boolean isAdminExistsByEmailAndPassword(String email, String password);
	
}
